<?php include('header.php');?>


    <!-- home section page  -->
    <section class="home-section">

        <div id="carouselExampleCaptions" class="carousel slide">
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active"
                    aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"
                    aria-label="Slide 2"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"
                    aria-label="Slide 3"></button>
            </div>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="img/crausal1.jpg" class="d-block w-100" alt="...">
                    <div class="carousel-caption d-none d-md-block">
                        <h5>Admission Open</h5>
                        <p>Some representative placeholder content for the first slide.</p>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="img/crausal2.jpg" class="d-block w-100" alt="...">
                    <div class="carousel-caption d-none d-md-block">
                        <h5>Admission Open</h5>
                        <p>Some representative placeholder content for the second slide.</p>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="img/crousal3.jpg" class="d-block w-100" alt="...">
                    <div class="carousel-caption d-none d-md-block">
                        <h5>Admission Open</h5>
                        <p>Some representative placeholder content for the third slide.</p>
                    </div>
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"
                data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"
                data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>

    </section>


    <!-- our facility  -->

    <section class="our-facility" id="our-facility">
        <h2>Our <span>facility</span></h2>
        <div class="container">
            <div class="row g-3">
                <div class="col-md-3">
                    <div data-aos="fade-up" class="our-content">
                        <span><i class="fa fa-graduation-cap"></i></span>
                        <h4>Skilled Instructors</h4>
                        <p>Diam elitr kasd sed at elitr sed ipsum justo dolor sed clita amet diam!</p>
                    </div>
                </div>

                <div class="col-md-3">
                    <div data-aos="fade-up" class="our-content">
                        <span><i class='fas fa-globe'></i></span>
                        <h4>Online Classes</h4>
                        <p>Diam elitr kasd sed at elitr sed ipsum justo dolor sed clita amet diam!</p>
                    </div>
                </div>

                <div class="col-md-3">
                    <div data-aos="fade-up" class="our-content">
                        <span><i class="fa fa-home"></i></span>
                        <h4>Home Projects</h4>
                        <p>Diam elitr kasd sed at elitr sed ipsum justo dolor sed clita amet diam!</p>
                    </div>
                </div>

                <div class="col-md-3">
                    <div data-aos="fade-up" class="our-content">
                        <span><i class='fas fa-book-open'></i></span>
                        <h4>Book Library</h4>
                        <p>Diam elitr kasd sed at elitr sed ipsum justo dolor sed clita amet diam!</p>
                    </div>
                </div>


            </div>
        </div>

    </section>


 <!-- about us section -->


    <!-- about us section -->

    <section class="about-section" >
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div data-aos="fade-up" class="about-img">
                        <img src="img/about.jpg" alt="" class="img-fluid">
                    </div>
                </div>

                <div class="col-md-6">
                    <div data-aos="fade-up" class="about-text">
                        <u>
                            <h4>about <span>us</span></h4>
                        </u>
                        <h2>welcome to our SRPIC kanpur</h2>
                        <p>
                            Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit. Aliqu diam amet diam et eos.
                            Clita erat ipsum et lorem et sit.

                            <br>
                            Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit. Aliqu diam amet diam et eos.
                            Clita erat ipsum et lorem et sit, sed stet lorem sit clita duo justo magna dolore erat amet
                            <br><br>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim numquam officiis, sit at nemo
                            in pariatur? Quis sunt eius officiis.
                        </p>
                        <div class="row gy-2 gx-4 mb-4">
                            <div class="col-sm-6">
                                <p class="mb-0"><i class="fa fa-arrow-right about-text-icon me-2"></i>Skilled
                                    Instructors</p>
                            </div>
                            <div class="col-sm-6">
                                <p class="mb-0"><i class="fa fa-arrow-right about-text-icon me-2"></i>Online Classes</p>
                            </div>
                            <div class="col-sm-6">
                                <p class="mb-0"><i class="fa fa-arrow-right about-text-icon me-2"></i>International
                                    Certificate</p>
                            </div>
                            <div class="col-sm-6">
                                <p class="mb-0"><i class="fa fa-arrow-right about-text-icon me-2"></i>Skilled
                                    Instructors</p>
                            </div>
                            <div class="col-sm-6">
                                <p class="mb-0"><i class="fa fa-arrow-right about-text-icon me-2"></i>Online Classes</p>
                            </div>
                            <div class="col-sm-6">
                                <p class="mb-0"><i class="fa fa-arrow-right about-text-icon me-2"></i>International
                                    Certificate</p>
                            </div>
                        </div>
                        <br>

                        <a class=" py-3 px-5 mt-2" href="">Read More</a>
                    </div>
                </div>

            </div>
        </div>
    </section>

  <!--course and placement   -->

  <section class="course">
    <div class="placement">
        <h2>Our course
        </h2>

        <div class="container">
            <div class="row g-3 ">
                <div data-aos="fade-up" class="col-md-4 same_col">
                    <div class="course-div">
                        <img src="img/bca.webp" alt="" class="img-fluid">

                        <h5>(B.C.A) (3 Year)</h5>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet id quaerat recusandae modi
                            laboriosam quo veniam. Quibusdam obcaecati ex cumque.</p>
                        <button class="course-button">Know more</button>
                    </div>
                </div>

                <div data-aos="fade-up" class="col-md-4 same_col">
                    <div class="course-div">
                        <img src="img/mca.webp" alt="" class="img-fluid">

                        <h5>(M.C.A) (2 Year)</h5>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet id quaerat recusandae modi
                            laboriosam quo veniam. Quibusdam obcaecati ex cumque.</p>
                        <button class="course-button">Know more</button>
                    </div>
                </div>

                <div data-aos="fade-up" class="col-md-4 same_col">
                    <div class="course-div">
                        <img src="img/bba.webp" alt="" class="img-fluid">

                        <h5>(B.B.A) (3 Year)</h5>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet id quaerat recusandae modi
                            laboriosam quo veniam. Quibusdam obcaecati ex cumque.</p>
                        <button class="course-button">Know more</button>
                    </div>
                </div>

                <div data-aos="fade-up" class="col-md-4 same_col">
                    <div class="course-div">
                        <img src="img/mba.webp" alt="" class="img-fluid">

                        <h5>(M.B.A) (2 Year)</h5>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet id quaerat recusandae modi
                            laboriosam quo veniam. Quibusdam obcaecati ex cumque.</p>
                        <button class="course-button">Know more</button>
                    </div>
                </div>

                <div data-aos="fade-up" class="col-md-4 same_col">
                    <div class="course-div">
                        <img src="img/llb_5.webp" alt="" class="img-fluid">

                        <h5>(B.A. L.L.B) (5 Year)</h5>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet id quaerat recusandae modi
                            laboriosam quo veniam. Quibusdam obcaecati ex cumque.</p>
                        <button class="course-button">Know more</button>
                    </div>
                </div>


                <div data-aos="fade-up" class="col-md-4 same_col">
                    <div class="course-div">
                        <img src="img/llb_3.webp" alt="" class="img-fluid">

                        <h5>(L.L.B) (3 Year)</h5>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet id quaerat recusandae modi
                            laboriosam quo veniam. Quibusdam obcaecati ex cumque.</p>
                        <button class="course-button">Know more</button>
                    </div>
                </div>




            </div>
        </div>
    </div>


</section>


    <!-- OUR TEAM -->

    <section class="our-team">
        <div class="container">
            <div class="team">
                <h2>Our team</h2>
                <div class=" row g-3">
                    <div data-aos="fade-up" class="col-md-3">
                        <div class="teacher">
                            <div class="teacher-img">
                                <img src="img/team-1.jpg" alt="" class="img-fluid">
                            </div>
                           <h4>kulmendr kaur</h4>
                           <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nulla, dolore.</p>
                        </div>
                    </div>

                    <div data-aos="fade-up" class="col-md-3">
                        <div class="teacher">
                            <div class="teacher-img">
                                <img src="img/team-2.jpg" alt="" class="img-fluid">
                            </div>
                           <h4>kulmendr kaur</h4>
                           <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nulla, dolore.</p>
                        </div>
                    </div>

                    <div data-aos="fade-up" class="col-md-3">
                        <div class="teacher">
                            <div class="teacher-img">
                                <img src="img/team-3.jpg" alt="" class="img-fluid">
                            </div>
                           <h4>kulmendr kaur</h4>
                           <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nulla, dolore.</p>
                        </div>
                    </div>

                    <div data-aos="fade-up" class="col-md-3">
                        <div class="teacher">
                            <div class="teacher-img">
                                <img src="img/team-4.jpg" alt="" class="img-fluid">
                            </div>
                           <h4>kulmendr kaur</h4>
                           <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nulla, dolore.</p>
                        </div>
                    </div>

                    <div data-aos="fade-up" class="col-md-3">
                        <div class="teacher">
                            <div class="teacher-img">
                                <img src="img/team-4.jpg" alt="" class="img-fluid">
                            </div>
                           <h4>kulmendr kaur</h4>
                           <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nulla, dolore.</p>
                        </div>
                    </div>

                    <div data-aos="fade-up" class="col-md-3">
                        <div class="teacher">
                            <div class="teacher-img">
                                <img src="img/team-3.jpg" alt="" class="img-fluid">
                            </div>
                           <h4>kulmendr kaur</h4>
                           <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nulla, dolore.</p>
                        </div>
                    </div>

                    <div data-aos="fade-up" class="col-md-3">
                        <div class="teacher">
                            <div class="teacher-img">
                                <img src="img/team-1.jpg" alt="" class="img-fluid">
                            </div>
                           <h4>kulmendr kaur</h4>
                           <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nulla, dolore.</p>
                        </div>
                    </div>

                    <div data-aos="fade-up" class="col-md-3">
                        <div class="teacher">
                            <div class="teacher-img">
                                <img src="img/team-2.jpg" alt="" class="img-fluid">
                            </div>
                           <h4>kulmendr kaur</h4>
                           <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nulla, dolore.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

   <!-- OUR GALLARY -->


   <section class="gallary">
    <div class="container">
        <div class="our-gallary">
            <h2> our gallary</h2>
            <div class="row g-2">
                <div data-aos="fade-up" class="col-md-4 gallary-col">
                    <div class="img-gallary">
                        <img src="img/course-1.jpg" alt="" class="img-fluid">
                    </div>
                </div>


                <div data-aos="fade-up" class="col-md-4 gallary-col">
                    <div class="img-gallary">
                        <img src="img/course-2.jpg" alt="" class="img-fluid">
                    </div>
                </div>


                <div data-aos="fade-up" class="col-md-4 gallary-col">
                    <div class="img-gallary">
                        <img src="img/course-3.jpg" alt="" class="img-fluid">
                    </div>
                </div>


                <div data-aos="fade-up" class="col-md-4 gallary-col">
                    <div class="img-gallary">
                        <img src="img/bba.webp" alt="" class="img-fluid">
                    </div>
                </div>


                <div data-aos="fade-up" class="col-md-4 gallary-col">
                    <div class="img-gallary">
                        <img src="img/bca.webp" alt="" class="img-fluid">
                    </div>
                </div>


                <div data-aos="fade-up" class="col-md-4 gallary-col">
                    <div class="img-gallary">
                        <img src="img/llb_3.webp" alt="" class="img-fluid">
                    </div>
                </div>


                <div data-aos="fade-up" class="col-md-4 gallary-col">
                    <div class="img-gallary">
                        <img src="img/llb_5.webp" alt="" class="img-fluid">
                    </div>
                </div>


                <div data-aos="fade-up" class="col-md-4 gallary-col">
                    <div class="img-gallary">
                        <img src="img/mba.webp" alt="" class="img-fluid">
                    </div>
                </div>


                <div data-aos="fade-up" class="col-md-4 gallary-col">
                    <div class="img-gallary">
                        <img src="img/mca.webp" alt="" class="img-fluid">
                    </div>
                </div>

               
            </div>
        </div>
    </div>


</section>



<!-- OUR PLACEMENT SECTION -->

    <section>
        <div class="placement">
            <h3>our collage recruitment company</h3>
            <marquee class="placement" direction="left" scrollamount="10">
                <img src="img/company-1.jpg" alt="">

                <img src="img/company-2.jpg" alt="">

                <img src="img/company-3.jpg" alt="">

                <img src="img/company-4.jpg" alt="">

                <img src="img/company-5.jpg" alt="">

                <img src="img/company-6.jpg" alt="">

                <img src="img/company-7.jpg" alt="">

                <img src="img/company-8.jpg" alt="">

                <img src="img/company-10.jpg" alt="">

                <img src="img/company-11.jpg" alt="">

                <img src="img/company-12.jpg" alt="">


                </marquee>
        </div>
    </section>


<!-- testomonial section -->
  <!-- Testimonial section -->

    
  <section class="section pb-5 pt-5" id="testimonials">
    <div class="container">
      <!-- ***** Section Title Start ***** -->
      <div class="row">
        <div class="col-lg-12">
          <div class="center-heading">
            <h2 class="section-title">Testimonials</h2>
          </div>
        </div>
        <div class="offset-lg-3 col-lg-6">
          <div class="center-text">
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry.</p>
          </div>
        </div>
      </div>
      <!-- ***** Section Title End ***** -->

      <div class="row testimonials-wrapper">
        <!-- ***** Testimonials Item Start ***** -->
        <div class="col-lg-4 col-md-6 col-sm-12">
          <div class="testimonials-item">
            <div class="user">
              <img src="img/image-300x300 (5).jpg" alt="">
            </div>
            <div class="testimonials-content">
              <h3 class="user-name">Mr. Akash</h3>
              <span>Web Designer</span>
              <div class="txt">
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s. </p>
              </div>
            </div>
          </div>
        </div>
        <!-- ***** Testimonials Item End ***** -->

        <!-- ***** Testimonials Item Start ***** -->
        <div class="col-lg-4 col-md-6 col-sm-12">
          <div class="testimonials-item">
            <div class="user">
              <img src="img/image-300x300 (4).jpg" alt="">
            </div>
            <div class="testimonials-content">
              <h3 class="user-name">Mr.Aman</h3>
              <span>Python Developer</span>
              <div class="txt">
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
              </div>
            </div>
          </div>
        </div>
        <!-- ***** Testimonials Item End ***** -->
        
        <!-- ***** Testimonials Item Start ***** -->
        <div class="col-lg-4 col-md-6 col-sm-12">
          <div class="testimonials-item">
            <div class="user">
              <img src="img/image-300x300 (3).jpg" alt="">
            </div>
            <div class="testimonials-content">
              <h3 class="user-name">Mr.Amit</h3>
              <span>Php Developer</span>
              <div class="txt">
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
              </div>
            </div>
          </div>
        </div>
        <!-- ***** Testimonials Item End ***** -->
        
        <!-- ***** Testimonials Item Start ***** -->
        <div class="col-lg-4 col-md-6 col-sm-12">
          <div class="testimonials-item">
            <div class="user">
              <img src="img/image-300x300.jpg" alt="">
            </div>
            <div class="testimonials-content">
              <h3 class="user-name">Mr.Alok</h3>
              <span>Java Developer</span>
              <div class="txt">
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
              </div>
            </div>
          </div>
        </div>
        <!-- ***** Testimonials Item End ***** -->
        
        <!-- ***** Testimonials Item Start ***** -->
        <div class="col-lg-4 col-md-6 col-sm-12">
          <div class="testimonials-item">
            <div class="user">
              <img src="img/image-300x300 (2).jpg" alt="">
            </div>
            <div class="testimonials-content">
              <h3 class="user-name">Mr.Abhay</h3>
              <span>.Net Developer</span>
              <div class="txt">
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
              </div>
            </div>
          </div>
        </div>
        <!-- ***** Testimonials Item End ***** -->
        
        <!-- ***** Testimonials Item Start ***** -->
        <div class="col-lg-4 col-md-6 col-sm-12">
          <div class="testimonials-item">
            <div class="user">
              <img src="img/image-300x300 (1).jpg" alt="">
            </div>
            <div class="testimonials-content">
              <h3 class="user-name">Mr.Ankush</h3>
              <span>C++ Developer</span>
              <div class="txt">
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
              </div>
            </div>
          </div>
        </div>
        <!-- ***** Testimonials Item End ***** -->
      </div>
    </div>
  </section>
  <!-- ***** Testimonials End ***** -->


<?php include('footer.php');?>