<?php include('header.php');?>

    <!-- bradecrams -->

    <section class="breadcrumb-section">
        <div class="container-fluid bg-primary py-5 mb-5 page-header">
            <div class="container py-5">
                <div class="row justify-content-center">
                    <div class="col-lg-10 text-center">
                        <h1 class=" text-about animated slideInDown">OUR TEAM</h1>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb justify-content-center">
                                <li class="breadcrumb-item"><a class="text-white" href="index.html">Home</a></li>

                                <li class="breadcrumb-item text-white active" aria-current="page">Our Team</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </section>




    <!-- OUR TEAM -->

        <section class="our-team">
            <div class="container">
                <div class="team">
                    <h2>Our team</h2>
                    <div class=" row g-3">
                        <div data-aos="zoom-in-up" class="col-md-3">
                            <div class="teacher">
                                <div class="teacher-img">
                                    <img src="img/team-1.jpg" alt="" class="img-fluid">
                                </div>
                               <h4>kulmendr kaur</h4>
                               <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nulla, dolore.</p>
                            </div>
                        </div>

                        <div data-aos="zoom-in-up" class="col-md-3">
                            <div class="teacher">
                                <div data-aos="zoom-in-up" class="teacher-img">
                                    <img src="img/team-2.jpg" alt="" class="img-fluid">
                                </div>
                               <h4>kulmendr kaur</h4>
                               <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nulla, dolore.</p>
                            </div>
                        </div>

                        <div data-aos="zoom-in-up" class="col-md-3">
                            <div class="teacher">
                                <div class="teacher-img">
                                    <img src="img/team-3.jpg" alt="" class="img-fluid">
                                </div>
                               <h4>kulmendr kaur</h4>
                               <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nulla, dolore.</p>
                            </div>
                        </div>

                        <div data-aos="zoom-in-up" class="col-md-3">
                            <div class="teacher">
                                <div class="teacher-img">
                                    <img src="img/team-4.jpg" alt="" class="img-fluid">
                                </div>
                               <h4>kulmendr kaur</h4>
                               <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nulla, dolore.</p>
                            </div>
                        </div>

                        <div data-aos="zoom-in-up" class="col-md-3">
                            <div class="teacher">
                                <div class="teacher-img">
                                    <img src="img/team-4.jpg" alt="" class="img-fluid">
                                </div>
                               <h4>kulmendr kaur</h4>
                               <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nulla, dolore.</p>
                            </div>
                        </div>

                        <div data-aos="zoom-in-up" class="col-md-3">
                            <div class="teacher">
                                <div class="teacher-img">
                                    <img src="img/team-3.jpg" alt="" class="img-fluid">
                                </div>
                               <h4>kulmendr kaur</h4>
                               <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nulla, dolore.</p>
                            </div>
                        </div>

                        <div data-aos="zoom-in-up" class="col-md-3">
                            <div class="teacher">
                                <div class="teacher-img">
                                    <img src="img/team-1.jpg" alt="" class="img-fluid">
                                </div>
                               <h4>kulmendr kaur</h4>
                               <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nulla, dolore.</p>
                            </div>
                        </div>

                        <div data-aos="zoom-in-up" class="col-md-3">
                            <div class="teacher">
                                <div class="teacher-img">
                                    <img src="img/team-2.jpg" alt="" class="img-fluid">
                                </div>
                               <h4>kulmendr kaur</h4>
                               <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nulla, dolore.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>





 <?php include('footer.php');?>