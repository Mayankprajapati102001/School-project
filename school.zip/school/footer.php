<!-- footer section -->

<!-- footer for mobile -->
<nav class="footer-mobile-nav d-md-none">
    <ul class="nav nav-justified">

        <li class="nav_item">
            <a class="nav_link inq" href="registration.php">
                <i class="fa fa-user"></i>
                <span>Register Now</span>
            </a>
        </li>

        <li class="nav_item">
            <a class="nav_link whatsapp" href="#">
                <i class='fab fa-whatsapp-square'></i>
                <span>Whatsapp</span>
            </a>
        </li>

        <li class="nav_item">
            <a class="nav_link call" href="#">
                <i class="fa fa-phone color-black"></i>
                <span>Phone</span>
            </a>
        </li>


    </ul>
    
</nav>
<!-- footer for mobile end -->

<footer class="about-footer" style="background-color: #181d38;">
    <div class="container py-5">
        <div class="row">
            <div class="col-md-3">
                <div class="quick-link">
                    <h5>quick link</h5>

                    <a href=""><i class='fas fa-chevron-right'></i> About us</a>

                    <a href=""><i class='fas fa-chevron-right'></i> Contact us</a>

                    <a href=""><i class='fas fa-chevron-right'></i> Privacy policy</a>

                    <a href=""><i class='fas fa-chevron-right'></i> Term & conditions</a>

                    <a href=""><i class='fas fa-chevron-right'></i> FAQ <sub>s</sub> & help</a>


                </div>
            </div>

            <div class="col-md-3">
                <div class="footer-contact">
                    <h5>contact</h5>
                    <p><i class='fas fa-map-marker-alt'></i> NH-34 Road, Kanpur, India </p>
                    <p><i class="fa fa-phone"></i> + 91 8887806732</p>
                    <p><i class="fa fa-envelope"></i> srpic.offical@gmail.com</p>
                </div>


                <div class="icon-div">
                    <div class="contact-icon">
                        <a href="https://twitter.com/yourprofile" target="_blank">
                            <i class="fab fa-twitter"></i>
                        </a>

                    </div>
                    <div class="contact-icon">
                        <a href="https://www.facebook.com/yourprofile" target="_blank">
                            <i class="fab fa-facebook-f"></i>
                        </a>

                    </div>
                    <div class="contact-icon">
                        <a href="https://in.linkedin.com/yourprofile" target="_blank">
                            <i class="fab fa-linkedin-in"></i>
                        </a>

                    </div>

                    <div class="contact-icon">
                        <a href="https://www.youtube.com/yourprofile" target="_blank">
                            <i class='fab fa-youtube'></i>
                        </a>

                    </div>

                </div>

            </div>




            <div class="col-md-3">
                <div class="footer-gallary">
                    <h5>gallary</h5>
                    <div class="container">
                        <div class="row g-2">
                            <div class="col-md-4">
                                <img src="img/course-1.jpg" alt="" class="img-fluid">
                            </div>

                            <div class="col-md-4">
                                <img src="img/course-2.jpg" alt="" class="img-fluid">
                            </div>

                            <div class="col-md-4">
                                <img src="img/course-3.jpg" alt="" class="img-fluid">
                            </div>

                            <div class="col-md-4">
                                <img src="img/course-3.jpg" alt="" class="img-fluid">
                            </div>

                            <div class="col-md-4">
                                <img src="img/course-1.jpg" alt="" class="img-fluid">
                            </div>

                            <div class="col-md-4">
                                <img src="img/course-2.jpg" alt="" class="img-fluid">
                            </div>

                        </div>
                    </div>
                </div>
            </div>


            <div class="col-md-3">
                <div class="footer-newslatter">
                    <h5>quick link</h5>
                    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Voluptates totam repudiandae
                        inventore, minima dolore nisi?</p>
                    <div class="position-relative mx-auto" style="max-width: 400px;">
                        <input class="form-control border-0 w-100 py-3 ps-4 pe-5" type="text" placeholder="Your email">
                        <button type="button" class="btn  py-2 position-absolute top-0 end-0 mt-2 me-2"
                            style="background-color: #06BBCC;">SignUp</button>
                    </div>
                </div>
            </div>


        </div>
    </div>
    <hr>


    <div class="container py-3">
        <div class="design-foot">


            <div class="row">
                <div class="col-md-12">
                    <div class="footer-design">
                        © <u>SRPIC Kanpur,</u> All Right Reserved. Designed By <u>BoffinWeb.</u>
                    </div>

                </div>

            </div>
        </div>
    </div>

</footer>


<!-- footer end -->




<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
    crossorigin="anonymous"></script>
<script src="script.js"></script>


<!-- aos script -->

<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
    AOS.init();
</script>


</body>

</html>