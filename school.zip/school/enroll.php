<?php include('header.php');?>

  <!-- bradecrams -->

  <section class="breadcrumb-section">
    <div class="container-fluid bg-primary py-5 mb-3 page-header">
      <div class="container py-5">
        <div class="row justify-content-center">
          <div class="col-lg-10 text-center">
            <h1 class=" text-about animated slideInDown">Enroll Now</h1>
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb justify-content-center">
                <li class="breadcrumb-item"><a class="text-white" href="index.html">Home</a></li>

                <li class="breadcrumb-item text-white active" aria-current="page">Enroll Now</li>
              </ol>
            </nav>
          </div>
        </div>
      </div>
    </div>
  </section>


  <!-- enroll html  -->

  <div class="container mb-3">

    <div class="admission">
        <h3>fill your admission form</h3>
    </div>
    
<form class="row g-3">
    <div class="col-md-6">
      <label for="inputFullname" class="form-label">Full Name</label>
      <input type="name" class="form-control" id="inputFullname" placeholder="Enter Your Full Name">
    </div>
    <div class="col-md-6">
      <label for="Email" class="form-label">Email</label>
      <input type="email" class="form-control" id="email" placeholder="Enter Your Email">
    </div>
    
    <div class="col-md-6">
        <label for="inputFullname" class="form-label">Father Name</label>
        <input type="name" class="form-control" id="inputFullname" placeholder="Enter Your Father Name">
      </div>
      <div class="col-md-6">
        <label for="mname" class="form-label">Mother Name</label>
        <input type="name" class="form-control" id="name" placeholder="Enter Your Mother Name ">
      </div>

      <div class="col-md-4">
        <label for="mname" class="form-label">High School</label>
        <input type="name" class="form-control" id="name" placeholder="Enter Your High School Stream">
      </div>
      <div class="col-md-4">
        <label for="mname" class="form-label">Intermediate</label>
        <input type="name" class="form-control" id="name" placeholder="Enter Your Intermediate Stream">
      </div>
      <div class="col-md-4">
        <label for="mname" class="form-label">Graduation ( if )</label>
        <input type="name" class="form-control" id="name" placeholder="Enter Your Graduation Stream">
      </div>

    <div class="col-12">
      <label for="inputAddress2" class="form-label">Address 2</label>
      <input type="text" class="form-control" id="inputAddress2" placeholder="Enter Your Address">
    </div>
    <div class="col-md-6">
      <label for="inputCity" class="form-label">City</label>
      <input type="text" class="form-control" id="inputCity" placeholder="Enter Your City">
    </div>
    <div class="col-md-4">
      <label for="inputState" class="form-label">Course</label>
      <select id="inputState" class="form-select">
        <option selected>Select Your Course</option>
        <option>BCA</option>
        <option>MCA</option>
        <option>BBA</option>
        <option>MBA</option>
        <option>BA.LLB</option>
        <option>LLB</option>

      </select>
    </div>
    <div class="col-md-2">
      <label for="inputZip" class="form-label">Zip</label>
      <input type="text" class="form-control" id="inputZip" placeholder="Pincode">
    </div>
    <div class="col-12">
      <div class="form-check">
        <input class="form-check-input" type="checkbox" id="gridCheck">
        <label class="form-check-label" for="gridCheck">
          Check me out
        </label>
      </div>
    </div>
    <div class="col-12">
      <a href="#" class="btn-1">Enroll Now</a>

    </div>
  </form>

</div>




<?php include('footer.php');?>