<?php include('header.php');?>
    <!-- bradecrams -->

    <section class="breadcrumb-section">
        <div class="container-fluid bg-primary py-5 mb-5 page-header">
            <div class="container py-5">
                <div class="row justify-content-center">
                    <div class="col-lg-10 text-center">
                        <h1 class=" text-about animated slideInDown">About Us</h1>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb justify-content-center">
                                <li class="breadcrumb-item"><a class="text-white" href="index.html">Home</a></li>

                                <li class="breadcrumb-item text-white active" aria-current="page">About</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- about us section -->

    <section class="about-section">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div data-aos="fade-right" class="about-img">
                        <img src="img/about.jpg" alt="" class="img-fluid">
                    </div>
                </div>

                <div class="col-md-6">
                    <div data-aos="fade-left" class="about-text">
                        <u>
                            <h4>about <span>us</span></h4>
                        </u>
                        <h2>welcome to our SRPIC kanpur</h2>
                        <p>
                            Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit. Aliqu diam amet diam et eos.
                            Clita erat ipsum et lorem et sit.

                            <br>
                            Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit. Aliqu diam amet diam et eos.
                            Clita erat ipsum et lorem et sit, sed stet lorem sit clita duo justo magna dolore erat amet
                            <br><br>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim numquam officiis, sit at nemo
                            in pariatur? Quis sunt eius officiis.
                        </p>
                        <div class="row gy-2 gx-4 mb-4">
                            <div class="col-sm-6">
                                <p class="mb-0"><i class="fa fa-arrow-right about-text-icon me-2"></i>Skilled
                                    Instructors</p>
                            </div>
                            <div class="col-sm-6">
                                <p class="mb-0"><i class="fa fa-arrow-right about-text-icon me-2"></i>Online Classes</p>
                            </div>
                            <div class="col-sm-6">
                                <p class="mb-0"><i class="fa fa-arrow-right about-text-icon me-2"></i>International
                                    Certificate</p>
                            </div>
                            <div class="col-sm-6">
                                <p class="mb-0"><i class="fa fa-arrow-right about-text-icon me-2"></i>Skilled
                                    Instructors</p>
                            </div>
                            <div class="col-sm-6">
                                <p class="mb-0"><i class="fa fa-arrow-right about-text-icon me-2"></i>Online Classes</p>
                            </div>
                            <div class="col-sm-6">
                                <p class="mb-0"><i class="fa fa-arrow-right about-text-icon me-2"></i>International
                                    Certificate</p>
                            </div>
                        </div>
                        <br>

                        <a class=" py-3 px-5 mt-2" href="">Read More</a>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <?php include('footer.php');?>