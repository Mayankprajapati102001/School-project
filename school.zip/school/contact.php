<?php include('header.php');?>


    <!-- bradecrams -->

    <section class="breadcrumb-section">
        <div class="container-fluid bg-primary py-5 mb-5 page-header">
            <div class="container py-5">
                <div class="row justify-content-center">
                    <div class="col-lg-10 text-center">
                        <h1 class=" text-about animated slideInDown">Contact</h1>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb justify-content-center">
                                <li class="breadcrumb-item"><a class="text-white" href="index.html">Home</a></li>

                                <li class="breadcrumb-item text-white active" aria-current="page">Contact</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <!-- contact us  -->

    <section class="contact-section">
        <div class="container">
            <div class="contact">
                <h6>
                    Contact Us
                </h6>
                <h1>Contact For Any Query</h1>

                <div class="row">
                    <div class="col-md-6">
                        <div data-aos="zoom-in" class="contact-div">
                            <h3>fill the contact form</h3>
                            <form class="row g-3">
                                <div class="col-md-6">
                                    <label for="inputEmail4" class="form-label">Email</label>
                                    <input type="email" class="form-control" id="inputEmail4" placeholder="Your Email">
                                </div>
                                <div class="col-md-6">
                                    <label for="inputName" class="form-label">Your Name</label>
                                    <input type="Name" class="form-control" id="inputNmae" placeholder="Your Name">
                                </div>


                                <div class="col-md-6">
                                    <label for="inputNumber" class="form-label">Contact Number</label>
                                    <input type="number" class="form-control" id="inputnumber"
                                        placeholder="Mobile number">
                                </div>
                                <div class="col-md-6">
                                    <label for="inputState" class="form-label">Class</label>
                                    <select id="inputState" class="form-select">
                                        <option selected>Choose...</option>
                                        <option>BCA</option>
                                        <option>MCA</option>
                                        <option>BBA</option>
                                        <option>MBA</option>
                                        <option>B.TECH</option>
                                        <option>M.TECH</option>
                                        

                                    </select>
                                </div>


                                <div class="form-floating">
                                    <textarea class="form-control" placeholder="Leave a comment here"
                                        id="floatingTextarea2" style="height: 100px"></textarea>
                                    <label for="floatingTextarea2">Message</label>
                                </div>
                                <div class="col-12">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="gridCheck">
                                        <label class="form-check-label" for="gridCheck">
                                            Check me out
                                        </label>
                                    </div>

                                </div>
                                <div class="col-12">
                                    <button type="submit" class="contact-button">Send Message</button>
                                </div>
                            </form>
                        </div>

                    </div>

                    <div class="col-md-6">
                        <div data-aos="zoom-in" class="map-div">
                            <iframe
                                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d228624.56107403865!2d80.17356783300114!3d26.447386602305613!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x399c4770b127c46f%3A0x1778302a9fbe7b41!2sKanpur%2C%20Uttar%20Pradesh!5e0!3m2!1sen!2sin!4v1739175739184!5m2!1sen!2sin"
                                width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"
                                referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </div>
                    </div>
                </div>
            </div>

        </div>


    </section>


    
<?php include('footer.php');?>