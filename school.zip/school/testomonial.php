<?php include('header.php');?>

    <!-- bradecrams -->

    <section class="breadcrumb-section">
        <div class="container-fluid bg-primary py-5 mb- page-header">
            <div class="container py-5">
                <div class="row justify-content-center">
                    <div class="col-lg-10 text-center">
                        <h1 class=" text-about animated slideInDown">Testimonial</h1>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb justify-content-center">
                                <li class="breadcrumb-item"><a class="text-white" href="index.html">Home</a></li>

                                <li class="breadcrumb-item text-white active" aria-current="page">Testimonial</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <!-- Testimonial section -->

    
    <section class="section pb-5 pt-5" id="testimonials">
        <div class="container">
          <!-- ***** Section Title Start ***** -->
          <div class="row">
            <div class="col-lg-12">
              <div class="center-heading">
                <h2 class="section-title">Testimonials</h2>
              </div>
            </div>
            <div class="offset-lg-3 col-lg-6">
              <div class="center-text">
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry.</p>
              </div>
            </div>
          </div>
          <!-- ***** Section Title End ***** -->
    
          <div class="row testimonials-wrapper">
            <!-- ***** Testimonials Item Start ***** -->
            <div class="col-lg-4 col-md-6 col-sm-12">
              <div class="testimonials-item">
                <div class="user">
                  <img src="img/image-300x300 (5).jpg" alt="">
                </div>
                <div class="testimonials-content">
                  <h3 class="user-name">Mr. Akash</h3>
                  <span>Web Designer</span>
                  <div class="txt">
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s. </p>
                  </div>
                </div>
              </div>
            </div>
            <!-- ***** Testimonials Item End ***** -->
    
            <!-- ***** Testimonials Item Start ***** -->
            <div class="col-lg-4 col-md-6 col-sm-12">
              <div class="testimonials-item">
                <div class="user">
                  <img src="img/image-300x300 (4).jpg" alt="">
                </div>
                <div class="testimonials-content">
                  <h3 class="user-name">Mr.Aman</h3>
                  <span>Python Developer</span>
                  <div class="txt">
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                  </div>
                </div>
              </div>
            </div>
            <!-- ***** Testimonials Item End ***** -->
            
            <!-- ***** Testimonials Item Start ***** -->
            <div class="col-lg-4 col-md-6 col-sm-12">
              <div class="testimonials-item">
                <div class="user">
                  <img src="img/image-300x300 (3).jpg" alt="">
                </div>
                <div class="testimonials-content">
                  <h3 class="user-name">Mr.Amit</h3>
                  <span>Php Developer</span>
                  <div class="txt">
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                  </div>
                </div>
              </div>
            </div>
            <!-- ***** Testimonials Item End ***** -->
            
            <!-- ***** Testimonials Item Start ***** -->
            <div class="col-lg-4 col-md-6 col-sm-12">
              <div class="testimonials-item">
                <div class="user">
                  <img src="img/image-300x300.jpg" alt="">
                </div>
                <div class="testimonials-content">
                  <h3 class="user-name">Mr.Alok</h3>
                  <span>Java Developer</span>
                  <div class="txt">
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                  </div>
                </div>
              </div>
            </div>
            <!-- ***** Testimonials Item End ***** -->
            
            <!-- ***** Testimonials Item Start ***** -->
            <div class="col-lg-4 col-md-6 col-sm-12">
              <div class="testimonials-item">
                <div class="user">
                  <img src="img/image-300x300 (2).jpg" alt="">
                </div>
                <div class="testimonials-content">
                  <h3 class="user-name">Mr.Abhay</h3>
                  <span>.Net Developer</span>
                  <div class="txt">
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                  </div>
                </div>
              </div>
            </div>
            <!-- ***** Testimonials Item End ***** -->
            
            <!-- ***** Testimonials Item Start ***** -->
            <div class="col-lg-4 col-md-6 col-sm-12">
              <div class="testimonials-item">
                <div class="user">
                  <img src="img/image-300x300 (1).jpg" alt="">
                </div>
                <div class="testimonials-content">
                  <h3 class="user-name">Mr.Ankush</h3>
                  <span>C++ Developer</span>
                  <div class="txt">
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                  </div>
                </div>
              </div>
            </div>
            <!-- ***** Testimonials Item End ***** -->
          </div>
        </div>
      </section>
      <!-- ***** Testimonials End ***** -->

   



<?php include('footer.php');?>