<?php include('header.php');?>

    <!-- bradecrams -->

    <section class="breadcrumb-section">
        <div class="container-fluid bg-primary py-5 mb- page-header">
            <div class="container py-5">
                <div class="row justify-content-center">
                    <div class="col-lg-10 text-center">
                        <h1 class=" text-about animated slideInDown">Course</h1>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb justify-content-center">
                                <li class="breadcrumb-item"><a class="text-white" href="index.html">Home</a></li>

                                <li class="breadcrumb-item text-white active" aria-current="page">Course</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--course and placement   -->

    <section class="course">
        <div class="placement">
            <h2>Our course
            </h2>

            <div class="container">
                <div class="row g-3 ">
                    <div data-aos="fade-right" class="col-md-4 same_col">
                        <div class="course-div">
                            <img src="img/bca.webp" alt="" class="img-fluid">

                            <h5>(B.C.A) (3 Year)</h5>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet id quaerat recusandae modi
                                laboriosam quo veniam. Quibusdam obcaecati ex cumque.</p>
                            <button class="course-button">Know more</button>
                        </div>
                    </div>

                    <div data-aos="fade-down" class="col-md-4 same_col">
                        <div class="course-div">
                            <img src="img/mca.webp" alt="" class="img-fluid">

                            <h5>(M.C.A) (2 Year)</h5>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet id quaerat recusandae modi
                                laboriosam quo veniam. Quibusdam obcaecati ex cumque.</p>
                            <button class="course-button">Know more</button>
                        </div>
                    </div>

                    <div data-aos="fade-left" class="col-md-4 same_col">
                        <div class="course-div">
                            <img src="img/bba.webp" alt="" class="img-fluid">

                            <h5>(B.B.A) (3 Year)</h5>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet id quaerat recusandae modi
                                laboriosam quo veniam. Quibusdam obcaecati ex cumque.</p>
                            <button class="course-button">Know more</button>
                        </div>
                    </div>

                    <div data-aos="fade-left" class="col-md-4 same_col">
                        <div class="course-div">
                            <img src="img/mba.webp" alt="" class="img-fluid">

                            <h5>(M.B.A) (2 Year)</h5>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet id quaerat recusandae modi
                                laboriosam quo veniam. Quibusdam obcaecati ex cumque.</p>
                            <button class="course-button">Know more</button>
                        </div>
                    </div>

                    <div data-aos="fade-up" class="col-md-4 same_col">
                        <div class="course-div">
                            <img src="img/llb_5.webp" alt="" class="img-fluid">

                            <h5>(B.A. L.L.B) (5 Year)</h5>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet id quaerat recusandae modi
                                laboriosam quo veniam. Quibusdam obcaecati ex cumque.</p>
                            <button class="course-button">Know more</button>
                        </div>
                    </div>


                    <div data-aos="fade-right" class="col-md-4 same_col">
                        <div class="course-div">
                            <img src="img/llb_3.webp" alt="" class="img-fluid">

                            <h5>(L.L.B) (3 Year)</h5>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet id quaerat recusandae modi
                                laboriosam quo veniam. Quibusdam obcaecati ex cumque.</p>
                            <button class="course-button">Know more</button>
                        </div>
                    </div>




                </div>
            </div>
        </div>


    </section>



<?php include('footer.php');?>

