<?php include('header.php');?>


    <!-- bradecrams -->

    <section class="breadcrumb-section">
        <div class="container-fluid bg-primary py-5 mb-5 page-header">
            <div class="container py-5">
                <div class="row justify-content-center">
                    <div class="col-lg-10 text-center">
                        <h1 class=" text-about animated slideInDown">Our Gallary</h1>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb justify-content-center">
                                <li class="breadcrumb-item"><a class="text-white" href="index.html">Home</a></li>

                                <li class="breadcrumb-item text-white active" aria-current="page">Our Gallary</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- OUR GALLARY -->


    <section class="gallary">
        <div class="container">
            <div class="our-gallary">
                <h2> our gallary</h2>
                <div class="row g-2">
                    <div data-aos="fade-down-right" class="col-md-4 gallary-col">
                        <div class="img-gallary">
                            <img src="img/course-1.jpg" alt="" class="img-fluid">
                        </div>
                    </div>


                    <div data-aos="fade-down" class="col-md-4 gallary-col">
                        <div class="img-gallary">
                            <img src="img/course-2.jpg" alt="" class="img-fluid">
                        </div>
                    </div>


                    <div data-aos="fade-down-left" class="col-md-4 gallary-col">
                        <div class="img-gallary">
                            <img src="img/course-3.jpg" alt="" class="img-fluid">
                        </div>
                    </div>


                    <div data-aos="fade-right" class="col-md-4 gallary-col">
                        <div class="img-gallary">
                            <img src="img/bba.webp" alt="" class="img-fluid">
                        </div>
                    </div>


                    <div data-aos="zoom-in" class="col-md-4 gallary-col">
                        <div class="img-gallary">
                            <img src="img/bca.webp" alt="" class="img-fluid">
                        </div>
                    </div>


                    <div data-aos="fade-left" class="col-md-4 gallary-col">
                        <div class="img-gallary">
                            <img src="img/llb_3.webp" alt="" class="img-fluid">
                        </div>
                    </div>


                    <div data-aos="fade-up-right" class="col-md-4 gallary-col">
                        <div class="img-gallary">
                            <img src="img/llb_5.webp" alt="" class="img-fluid">
                        </div>
                    </div>


                    <div data-aos="fade-up" class="col-md-4 gallary-col">
                        <div class="img-gallary">
                            <img src="img/mba.webp" alt="" class="img-fluid">
                        </div>
                    </div>


                    <div data-aos="fade-up-left" class="col-md-4 gallary-col">
                        <div class="img-gallary">
                            <img src="img/mca.webp" alt="" class="img-fluid">
                        </div>
                    </div>

                   
                </div>
            </div>
        </div>


    </section>

  <?php include('footer.php');?>