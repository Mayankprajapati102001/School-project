

<?php include("header.php");?>

<!-- BREADCRAM -->





    <!-- new Arrival -->

    <section class="new" id="new">
        <div class="heading">
            <span>New Collection</span>
            <h2>Best Selling</h2>
        </div>

        <div class="new-container">
            <div class="box">
                <div class="box-img">
                    <img src="imges/new1.jpg" alt="image">
                </div>

                <div class="title-price">
                    <h3>Rustic Chair</h3>
                    <div class="stars">
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star-half' ></i>
                    </div>
                </div>
                <span>$30</span>
                <i class='bx bx-cart' ></i>
            </div>

            <div class="box">
                <div class="box-img">
                    <img src="imges/new2.jpg" alt="image">
                </div>

                <div class="title-price">
                    <h3>Bright Yellow Chair</h3>
                    <div class="stars">
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star-half' ></i>
                    </div>
                </div>
                <span>$40</span>
                <i class='bx bx-cart' ></i>
            </div>

            <div class="box">
                <div class="box-img">
                    <img src="imges/new3.jpg" alt="image">
                </div>

                <div class="title-price">
                    <h3>White Chair</h3>
                    <div class="stars">
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star-half' ></i>
                    </div>
                </div>
                <span>$35</span>
                <i class='bx bx-cart' ></i>
            </div>

            <div class="box">
                <div class="box-img">
                    <img src="imges/new1.jpg" alt="image">
                </div>

               

        </div>
    </section>


    <?php include("footer.php");?>