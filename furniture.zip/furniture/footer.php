

    <!-- footer section & Subscribe -->
    <section class="newsletter" id="contact">
        <h2>Subscribe to Newsletter</h2>
        <div class="news-box">
            <input type="text" placeholder="Enter your email">
            <a href="#" class="btn">Subscribe</a>
        </div>
    </section>

    <section class="footer" id="footer">
        <div class="footer-box">
            <h2>Brand <span>X</span></h2>
            <p>Invest in your comfort and happiness.</p>
            <div class="social">
                <a href="#"><i class='bx bxl-facebook'></i></a>
                <a href="#"><i class='bx bxl-twitter'></i></a>
                <a href="#"><i class='bx bxl-instagram'></i></a>
            </div>
        </div>

        <div class="footer-box">
            <h3>Services</h3>
            <li><a href="#">Product</a></li>
            <li><a href="#">Help & Support</a></li>
            <li><a href="#">Pricing</a></li>
            <li><a href="#">FAQ</a></li>
        </div>

        <div class="footer-box">
            <h3>Product</h3>
            <li><a href="#">Sofa's</a></li>
            <li><a href="#">Chair's</a></li>
            <li><a href="#">Living Room</a></li>
            <li><a href="#">Office</a></li>
        </div>

        <div class="footer-box contact-info">
            <h3>Contact</h3>
            <span>NH-34 Kanpur Uttar Pradesh</span>
            <span>+91 8887807832</span>
            <span>maxfurniture@gmail.com</span>
        </div>
    </section>

    <div class="copyright">
        <p>&#169; <span>MAYANK</span>. All rights reserved</p>
    </div>

    <script src="main.js"></script>
</body>
</html>