
<?php include("header.php");?>


<!-- home section -->
    <section class="home" id="home">
        <div class="home-text">
            <h1>Your <span>Comfort</span> <br> Is Our <span>Happiness</span></h1>
            <p>We create an environment where you can truly relax and be yourself</p>
            <a href="#shop" class="btn">Shop Now</a>
        </div>
    </section>


    <!-- new Arrival -->

    <section class="shop" id="shop">
        <div class="heading">
            <span>New Arrival</span>
            <h2>Shop Now</h2>
        </div>

        <div class="shop-container">
            <div class="box">
                <div class="box-img">
                    <img src="imges/p1.jpg" alt="image" class="img-fluid">

                </div>

                <div class="title-price">
                    <h3>Gray Chair</h3>
                    <div class="stars">
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star-half' ></i>
                    </div>
                </div>
                <span>$45</span>
                <i class='bx bx-cart' ></i>
            </div>

            <div class="box">
                <div class="box-img">
                    <img src="imges/p2.jpg" alt="image">
                </div>

                <div class="title-price">
                    <h3>Blue Chair</h3>
                    <div class="stars">
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star-half' ></i>
                    </div>
                </div>
                <span>$50</span>
                <i class='bx bx-cart' ></i>
            </div>

            <div class="box">
                <div class="box-img">
                    <img src="imges/p3.jpg" alt="image">
                </div>

                <div class="title-price">
                    <h3>Pink Chair</h3>
                    <div class="stars">
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star-half' ></i>
                    </div>
                </div>
                <span>$60</span>
                <i class='bx bx-cart' ></i>
            </div>

            <div class="box">
                <div class="box-img">
                    <img src="imges/p4.jpg" alt="image">
                </div>

                <div class="title-price">
                    <h3>Tripod Gray Chair</h3>
                    <div class="stars">
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star-half' ></i>
                    </div>
                </div>
                <span>$40</span>
                <i class='bx bx-cart' ></i>
            </div>

            <div class="box">
                <div class="box-img">
                    <img src="imges/p5.jpg" alt="image">
                </div>

                <div class="title-price">
                    <h3>Tripod Black Chair</h3>
                    <div class="stars">
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star-half' ></i>
                    </div>
                </div>
                <span>$45</span>
                <i class='bx bx-cart' ></i>
            </div>

            <div class="box">
                <div class="box-img">
                    <img src="imges/p6.jpg" alt="image">
                </div>

                <div class="title-price">
                    <h3>Black Chair</h3>
                    <div class="stars">
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star-half' ></i>
                    </div>
                </div>
                <span>$50</span>
                <i class='bx bx-cart' ></i>
            </div>
        </div>
    </section>


    <!-- new Collection -->

    <section class="new" id="new">
        <div class="heading">
            <span>New Collection</span>
            <h2>Best Selling</h2>
        </div>

        <div class="new-container">
            <div class="box">
                <div class="box-img">
                    <img src="imges/new1.jpg" alt="image">
                </div>

                <div class="title-price">
                    <h3>Rustic Chair</h3>
                    <div class="stars">
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star-half' ></i>
                    </div>
                </div>
                <span>$30</span>
                <i class='bx bx-cart' ></i>
            </div>

            <div class="box">
                <div class="box-img">
                    <img src="imges/new2.jpg" alt="image">
                </div>

                <div class="title-price">
                    <h3>Bright Yellow Chair</h3>
                    <div class="stars">
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star-half' ></i>
                    </div>
                </div>
                <span>$40</span>
                <i class='bx bx-cart' ></i>
            </div>

            <div class="box">
                <div class="box-img">
                    <img src="imges/new3.jpg" alt="image">
                </div>

                <div class="title-price">
                    <h3>White Chair</h3>
                    <div class="stars">
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star' ></i>
                        <i class='bx bxs-star-half' ></i>
                    </div>
                </div>
                <span>$35</span>
                <i class='bx bx-cart' ></i>
            </div>
        </div>
    </section>


    <!-- about section -->

    <section class="about">
        <div class="about-img">
            <img src="https://i.postimg.cc/jjtCJp6P/about.jpg" alt="image">
        </div>

        <div class="about-text">
            <span>About us</span>
            <h2>Furniture is a important part <br>for your comfort</h2>
            <p>We spend a significant portion of our lives within the walls of our homes. It's where we recharge, relax, and create memories</p>
            <p>Investing in quality furniture is an investment in your comfort and happiness. It's about creating a space that reflects your personality and nourishes your soul</p>
            <a href="#shop" class="btn">Learn More</a>
        </div>
    </section>


    <!-- our partners brand -->

    <section class="brands" id="brands">
        <div class="heading">
            <span>Brands</span>
            <h2>Our Brand Partners</h2>
        </div>

        <div class="brands-container">

            <img src="https://i.postimg.cc/JzPtZTpF/Google.png" alt="brand image">
            <img src="https://i.postimg.cc/sxYgXKBw/amazon.png" alt="brand image">
            <img src="https://i.postimg.cc/GhRpN0NN/netflix.png" alt="brand image">
            <img src="https://i.postimg.cc/jSgdLD50/tesla.png" alt="brand image">
            <img src="https://i.postimg.cc/hGX4xKzJ/starbucks.png" alt="brand image">
            <img src="https://i.postimg.cc/G3FLv72j/zoom.png" alt="brand image">
            
            
        </div>
    </section>

<?php include("footer.php");?>