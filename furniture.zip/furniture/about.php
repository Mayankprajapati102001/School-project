<?php include("header.php"); ?>




   


<!-- about section -->

<section class="about " >
    <div class="about-img">
        <img src="imges/about.jpg" alt="image">
    </div>

    <div class="about-text">
        <span>About us</span>
        <h2>Furniture is a important part <br>for your comfort</h2>
        <p>We spend a significant portion of our lives within the walls of our homes. It's where we recharge, relax, and
            create memories</p>
        <p>Investing in quality furniture is an investment in your comfort and happiness. It's about creating a space
            that reflects your personality and nourishes your soul</p>
        <a href="#shop" class="btn">Learn More</a>
    </div>
</section>

<?php include("footer.php"); ?>