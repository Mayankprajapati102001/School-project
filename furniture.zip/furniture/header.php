<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Max Furnitures</title>
    <link rel="stylesheet" href="styles.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <header>
        <a href="#" class="logo">Brand <span>X.</span></a>
        <i class='bx bx-menu' id="menu-icon"></i>

        <ul class="navbar">
            <li><a href="index.php">Home</a></li>
            <li><a href="shopnow.php">Shop</a></li>
            <li><a href="#new">New Arrivals</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="#brands">Our Partners</a></li>
            <li><a href="#contact">Contact</a></li>
        </ul>
    </header>
